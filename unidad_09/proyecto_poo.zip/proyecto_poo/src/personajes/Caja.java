package personajes;

public class Caja extends Atomo{
    
    public Caja(int cordx, int cordy){
        super(cordx, cordy);
    }

    public String toString(){
        return "C░";
    }
}
