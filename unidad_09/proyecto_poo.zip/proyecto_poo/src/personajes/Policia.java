package personajes;

public class Policia extends Atomo{

    public Policia(int cordx, int cordy){
        super(cordx, cordy);
    }

    public String toString(){
        return "P░";
    }
}
