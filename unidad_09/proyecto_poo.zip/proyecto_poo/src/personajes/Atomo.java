package personajes;

public abstract class Atomo {
    int cordx;
    int cordy;

    public Atomo(int cordx, int cordy){
        this.cordx = cordx;
        this.cordy = cordy;
    }
}
