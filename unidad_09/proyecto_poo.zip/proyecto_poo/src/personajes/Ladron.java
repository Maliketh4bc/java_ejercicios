package personajes;

public class Ladron extends Atomo{

    public Ladron(int cordx, int cordy){
        super(cordx, cordy);
    }

    public String toString(){
        return "L░";
    }
}
